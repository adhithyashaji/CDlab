
file=open("input.txt","r")

identifiers=["include","stdio.h","main","fact","i","n","printf","scanf","Enter","number","factorial","x"] 

literals=['1','"\nEnter number"','%d','factorial=%d','%f']

keywordlist=["auto","break","case","char","const","continue","default","do","double","else","enum","extern","float","for","goto","if","int","long","register","return","short","signed","sizeof","static","struct","switch","typedef","union","unsigned","void","volatile","while"]

delimiters=['(',')',',','{','}',';','>','<']

operators=['=','+','++','<=','*','&']


k=[]
d=[]
o=[]
i=[]
l=[]
lines=file.read().splitlines()


for line in lines:
	words=line.split()
	for item in words:
		
		if item in keywordlist:
			k.append(item)
#       if item.isalpha()==True:
     #               i.append(item)

		else:
			if item in identifiers:
				i.append(item)
			else:
				for j in delimiters:
					if j in item:
						item=item.replace(j,' ')
						if j not in d:
							d.append(j)

				for j in operators:
					if j in item:
						item=item.replace(j,' ')
						if j not in o:
							o.append(j)
			        if item in identifiers:
                                	i.append(item)

			#	if item.isalpha()==True:
			#		i.append(item)
				else:
					new=item.split()
#					print(new)					
					for n in new:
						if n in keywordlist:
							k.append(n)
						elif n not in i:
							i.append(n)

print "\n"
print "Identifiers are	   : \n ",i
print "\n"
print "Keywords are        : \n ",k
print "\n"
print "Special symbolos are: \n ",d
print "\n"
print "Operators are	   : \n ",o
print "\n"
print "Literals are	   : \n "
